============================================================
  LOCAL / HOUSING ERA IMAGES — puebloleakrepairpros.com  |  Pueblo, CO
============================================================

FOLDER:      images/local/
DIMENSIONS:  800 x 500 px
FILE SIZE:   Target under 120 KB each  |  WebP preferred, JPG acceptable
FORMAT:      JPG or WebP  |  RGB color space

IMPORTANT NOTES:
LOCAL IMAGES — UNIQUE PER SITE
These 3 images appear in the Housing Era Callout Strip on the homepage.
Each represents a different era of Pueblo County's residential construction.
They appear as small cards (~300x200 display size) but should be saved at full resolution.

Era 1 — Pre-1955 Galvanized Era:
  Subject: Historic Bessemer, Mesa Junction, or Downtown Pueblo streets.
  Worker cottages, Victorian-era homes, or CF&I-era brick construction.
  Target neighborhoods: Bessemer, Mesa Junction, Salt Creek, Downtown.

Era 2 — 1965-1985 Copper Era:
  Subject: Mid-century tract homes in Belmont, Lakeview, or Country Club.
  Ranch-style single-story homes, cul-de-sacs, or 1970s residential streets.
  Target neighborhoods: Belmont, Lakeview, Country Club, Sunset Park.

Era 3 — 1990s+ PEX Era:
  Subject: Newer suburban development in Pueblo West or Aberdeen.
  Larger homes, attached garages, modern subdivision character.
  Target neighborhoods: Pueblo West, Aberdeen, newer North Side.

────────────────────────────────────────────────────────────
  FILES TO CREATE (3 images)
────────────────────────────────────────────────────────────

  01. era-pre1955.jpg
      Visual: Older pre-1960 housing in Pueblo — historic residential streets or craftsman homes

  02. era-1965-85.jpg
      Visual: Mid-century 1960s-1980s residential neighborhood in Pueblo — ranch style homes

  03. era-1990s-plus.jpg
      Visual: Newer 1990s-2000s suburban development in Pueblo — modern subdivision homes

────────────────────────────────────────────────────────────
  STATUS TRACKING
────────────────────────────────────────────────────────────

  Mark each file DONE below as you complete it:

  [ ] era-pre1955.jpg
  [ ] era-1965-85.jpg
  [ ] era-1990s-plus.jpg

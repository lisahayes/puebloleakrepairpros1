============================================================
  LOCAL / HOUSING ERA IMAGES — coloradospringsleak repairpros.com  |  Colorado Springs, CO
============================================================

FOLDER:      images/local/
DIMENSIONS:  800 x 500 px
FILE SIZE:   Target under 120 KB each  |  WebP preferred, JPG acceptable
FORMAT:      JPG or WebP  |  RGB color space

IMPORTANT NOTES:
LOCAL IMAGES — UNIQUE PER SITE
These 3 images appear in the Housing Era Callout Strip on the homepage.
Each represents a different era of Colorado Springs's residential construction.

Era 1 — Pre-1960s Older Housing:
  Subject: Oldest residential streets or historic neighborhoods in Colorado Springs.
  Pre-war homes, craftsman bungalows, or early 20th century housing stock.

Era 2 — 1965-1985 Mid-Century:
  Subject: Mid-century tract homes or ranch-style residential development.
  1960s-1980s neighborhoods in Colorado Springs — typical of this era.

Era 3 — 1990s+ Newer Construction:
  Subject: Newer suburban development or modern residential areas in Colorado Springs.
  Larger homes, attached garages, contemporary subdivision character.

────────────────────────────────────────────────────────────
  FILES TO CREATE (3 images)
────────────────────────────────────────────────────────────

  01. era-pre1955.jpg
      Visual: Older pre-1960 housing in Colorado Springs — historic residential streets or craftsman homes

  02. era-1965-85.jpg
      Visual: Mid-century 1960s-1980s residential neighborhood in Colorado Springs — ranch style homes

  03. era-1990s-plus.jpg
      Visual: Newer 1990s-2000s suburban development in Colorado Springs — modern subdivision homes

────────────────────────────────────────────────────────────
  STATUS TRACKING
────────────────────────────────────────────────────────────

  Mark each file DONE below as you complete it:

  [ ] era-pre1955.jpg
  [ ] era-1965-85.jpg
  [ ] era-1990s-plus.jpg

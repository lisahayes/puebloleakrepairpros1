============================================================
  SERVICE PAGE IMAGES — ftcollinsleakrepairpros.com  |  GENERIC (same across all 50 sites)
============================================================

FOLDER:      images/services/
DIMENSIONS:  800 x 500 px
FILE SIZE:   Target under 120 KB each  |  WebP preferred, JPG acceptable
FORMAT:      JPG or WebP  |  RGB color space  |  No text overlays

IMPORTANT NOTES:
SERVICE PAGE IMAGES — SHARED ACROSS ALL 50 SITES
These 54 images are created ONCE and copied into every site.
DO NOT include any city name, address, or location-specific content.
All images must be generic plumbing/leak detection photography.

Each image maps 1-to-1 to a service page by filename.
The filename must match exactly (including hyphens, no spaces).

BLOG PAGES reuse these same service images — no separate blog images needed.
LOCATION PAGES have no images — skip entirely.

────────────────────────────────────────────────────────────
  FILES TO CREATE (54 images)
────────────────────────────────────────────────────────────

  01. slab-leak-detection-and-repair.jpg
      Visual: Concrete slab floor with moisture seeping up; acoustic detection equipment nearby. No text overlay.

  02. pinhole-leak-detection-and-repair.jpg
      Visual: Close-up corroded copper pipe with small pinhole drip. Green oxidation visible on pipe surface.

  03. foundation-leak-detection-and-repair.jpg
      Visual: Basement foundation wall with water staining, efflorescence (white mineral deposits), and moisture damage.

  04. pipe-leak-detection-and-repair.jpg
      Visual: Plumber repairing burst or leaking pipe. Wall cavity or under-sink setting. Tools visible.

  05. sewer-line-leak-detection-and-repair.jpg
      Visual: Sewer camera inspection equipment at a cleanout access point. Camera reel and monitor visible.

  06. water-heater-leak-detection-and-repair.jpg
      Visual: Water heater tank with moisture pooling at base. Technician inspecting connections.

  07. plumbing-leak-detection-and-repair.jpg
      Visual: Plumber with detection equipment in residential home interior. Professional setting.

  08. underground-leak-detection-and-repair.jpg
      Visual: Technician kneeling in yard using acoustic correlator probes on grass or soil surface.

  09. water-line-leak-detection-and-repair.jpg
      Visual: Exposed main service line in open trench. Repair coupling or joint visible.

  10. toilet-leak-detection-and-repair.jpg
      Visual: Toilet base with water stain on tile floor. Wax ring partially visible below toilet.

  11. faucet-leak-detection-and-repair.jpg
      Visual: Dripping kitchen or bathroom faucet. Water droplet close-up. No branding visible.

  12. sink-leak-detection-and-repair.jpg
      Visual: Open cabinet under sink — wet P-trap connection or drain fitting dripping.

  13. drain-leak-detection-and-repair.jpg
      Visual: Drain pipe section with water staining or active drip at pipe joint.

  14. shower-leak-detection-and-repair.jpg
      Visual: Shower floor tile with grout damage. Drain area with technician performing flood test.

  15. ceiling-leak-detection-and-repair.jpg
      Visual: Brown circular water stain on white painted ceiling drywall. High-contrast, clean shot.

  16. wall-leak-detection-and-repair.jpg
      Visual: Thermal imaging camera display showing heat anomaly on wall. Temperature colors visible.

  17. bathroom-leak-detection-and-repair.jpg
      Visual: Technician with moisture meter scanning bathroom wall or floor tile.

  18. bathtub-leak-detection-and-repair.jpg
      Visual: Bathtub drain area. Plumber inspecting overflow plate or drain gasket connection.

  19. copper-pipe-leak-detection-and-repair.jpg
      Visual: Old copper pipe section — heavy green patina, pinholes visible, clear corrosion.

  20. pvc-pipe-leak-detection-and-repair.jpg
      Visual: PVC drain pipe with visible crack or root intrusion at joint connection.

  21. pipeline-leak-detection-and-repair.jpg
      Visual: Long buried pipeline section with two acoustic sensor probes clamped on pipe body.

  22. hose-bib-leak-detection-and-repair.jpg
      Visual: Exterior wall faucet (hose bib/sillcock) with frost damage crack. Winter context.

  23. pressure-regulator-valve-leak-detection-and-repair.jpg
      Visual: Pressure regulator valve on copper supply line. Pressure gauge with readable numbers.

  24. sump-pump-leak-detection-and-repair.jpg
      Visual: Sump pump inside concrete basement pit. Discharge pipe and check valve clearly visible.

  25. pool-leak-detection-and-repair.jpg
      Visual: Residential swimming pool. Technician with dye test syringe near fitting or return jet.

  26. above-ground-pool-leak-detection-and-repair.jpg
      Visual: Above-ground pool — wet ground patch beneath wall or near pump connection hose.

  27. inground-pool-leak-detection-and-repair.jpg
      Visual: Inground pool with pressure testing gauge connected to plumbing access port.

  28. pool-liner-leak-detection-and-repair.jpg
      Visual: Pool vinyl liner close-up — dye test syringe positioned near suspected tear point.

  29. spa-leak-detection-and-repair.jpg
      Visual: Spa jet fitting — technician checking gasket seal with screwdriver or wrench.

  30. hot-tub-leak-detection-and-repair.jpg
      Visual: Hot tub service panel open — pump union fittings and plumbing bundle clearly visible.

  31. sprinkler-system-leak-detection-and-repair.jpg
      Visual: Sprinkler head in lawn with water pooling around the base from underground lateral leak.

  32. irrigation-leak-detection-and-repair.jpg
      Visual: Drip irrigation tubing in garden bed — wet soil patch between emitter locations.

  33. yard-leak-detection-and-repair.jpg
      Visual: Dry lawn/yard with isolated wet muddy patch. Technician probing soil with detection rod.

  34. crawl-space-leak-detection-and-repair.jpg
      Visual: Crawl space interior — moisture on vapor barrier sheeting, wet or damaged insulation.

  35. basement-leak-detection-and-repair.jpg
      Visual: Basement concrete floor — standing water near foundation wall corner.

  36. basement-water-leak-detection-and-repair.jpg
      Visual: Basement block or poured concrete wall — water staining and white efflorescence deposits.

  37. residential-leak-detection-and-repair.jpg
      Visual: Technician with acoustic detection equipment inside residential living space or hallway.

  38. commercial-leak-detection-and-repair.jpg
      Visual: Commercial building utility room or hallway — professional detection equipment in use.

  39. whole-house-repipe-service.jpg
      Visual: New color-coded PEX tubing running through exposed wall framing. Clean modern install.

  40. garbage-disposal-leak-detection-and-repair.jpg
      Visual: Under-sink cabinet — garbage disposal with drip at flange or dishwasher inlet connection.

  41. dishwasher-leak-detection-and-repair.jpg
      Visual: Dishwasher pulled forward from cabinet — water stain or moisture visible on floor beneath.

  42. washing-machine-leak-detection-and-repair.jpg
      Visual: Washing machine supply hose connection at wall valve. Hose clamp and valve handle visible.

  43. acoustic-leak-detection.jpg
      Visual: Technician wearing headphones holding acoustic ground microphone probe on floor surface.

  44. helium-leak-detection.jpg
      Visual: Helium detector probe (wand device) being swept slowly over ground or floor surface.

  45. electronic-leak-detection.jpg
      Visual: Electronic leak detection unit — digital display panel and contact probe on surface.

  46. ultrasonic-leak-detection.jpg
      Visual: Ultrasonic sensor aimed at wall surface. Signal frequency display visible on handheld unit.

  47. thermal-imaging-leak-detection.jpg
      Visual: Infrared thermal camera display showing false-color temperature map of floor or wall.

  48. tracer-gas-leak-detection.jpg
      Visual: Gas detector probe positioned over ground — nitrogen/hydrogen tracer gas equipment nearby.

  49. sonar-leak-detection.jpg
      Visual: Sonar detection unit connected at pipe access port or meter vault. Readout display visible.

  50. pinpoint-leak-detection.jpg
      Visual: Technician marking exact floor location with chalk after acoustic probe peak confirmation.

  51. non-invasive-leak-detection.jpg
      Visual: Technician scanning intact wall surface with probe — no cuts, holes, or damage visible.

  52. trenchless-leak-detection.jpg
      Visual: Pipe camera sonde equipment setup. Locator receiver unit on ground surface above pipe.

  53. shower-pan-leak-detection-and-repair.jpg
      Visual: Shower drain with rubber test plug installed. Flood test water level marked on wall tile.

  54. toilet-tank-leak-detection-and-repair.jpg
      Visual: Toilet tank with lid removed — flapper, fill valve, and overflow tube all clearly visible.

────────────────────────────────────────────────────────────
  STATUS TRACKING
────────────────────────────────────────────────────────────

  Mark each file DONE below as you complete it:

  [ ] slab-leak-detection-and-repair.jpg
  [ ] pinhole-leak-detection-and-repair.jpg
  [ ] foundation-leak-detection-and-repair.jpg
  [ ] pipe-leak-detection-and-repair.jpg
  [ ] sewer-line-leak-detection-and-repair.jpg
  [ ] water-heater-leak-detection-and-repair.jpg
  [ ] plumbing-leak-detection-and-repair.jpg
  [ ] underground-leak-detection-and-repair.jpg
  [ ] water-line-leak-detection-and-repair.jpg
  [ ] toilet-leak-detection-and-repair.jpg
  [ ] faucet-leak-detection-and-repair.jpg
  [ ] sink-leak-detection-and-repair.jpg
  [ ] drain-leak-detection-and-repair.jpg
  [ ] shower-leak-detection-and-repair.jpg
  [ ] ceiling-leak-detection-and-repair.jpg
  [ ] wall-leak-detection-and-repair.jpg
  [ ] bathroom-leak-detection-and-repair.jpg
  [ ] bathtub-leak-detection-and-repair.jpg
  [ ] copper-pipe-leak-detection-and-repair.jpg
  [ ] pvc-pipe-leak-detection-and-repair.jpg
  [ ] pipeline-leak-detection-and-repair.jpg
  [ ] hose-bib-leak-detection-and-repair.jpg
  [ ] pressure-regulator-valve-leak-detection-and-repair.jpg
  [ ] sump-pump-leak-detection-and-repair.jpg
  [ ] pool-leak-detection-and-repair.jpg
  [ ] above-ground-pool-leak-detection-and-repair.jpg
  [ ] inground-pool-leak-detection-and-repair.jpg
  [ ] pool-liner-leak-detection-and-repair.jpg
  [ ] spa-leak-detection-and-repair.jpg
  [ ] hot-tub-leak-detection-and-repair.jpg
  [ ] sprinkler-system-leak-detection-and-repair.jpg
  [ ] irrigation-leak-detection-and-repair.jpg
  [ ] yard-leak-detection-and-repair.jpg
  [ ] crawl-space-leak-detection-and-repair.jpg
  [ ] basement-leak-detection-and-repair.jpg
  [ ] basement-water-leak-detection-and-repair.jpg
  [ ] residential-leak-detection-and-repair.jpg
  [ ] commercial-leak-detection-and-repair.jpg
  [ ] whole-house-repipe-service.jpg
  [ ] garbage-disposal-leak-detection-and-repair.jpg
  [ ] dishwasher-leak-detection-and-repair.jpg
  [ ] washing-machine-leak-detection-and-repair.jpg
  [ ] acoustic-leak-detection.jpg
  [ ] helium-leak-detection.jpg
  [ ] electronic-leak-detection.jpg
  [ ] ultrasonic-leak-detection.jpg
  [ ] thermal-imaging-leak-detection.jpg
  [ ] tracer-gas-leak-detection.jpg
  [ ] sonar-leak-detection.jpg
  [ ] pinpoint-leak-detection.jpg
  [ ] non-invasive-leak-detection.jpg
  [ ] trenchless-leak-detection.jpg
  [ ] shower-pan-leak-detection-and-repair.jpg
  [ ] toilet-tank-leak-detection-and-repair.jpg

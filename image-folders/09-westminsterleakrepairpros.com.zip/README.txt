============================================================
  IMAGE FOLDERS — westminsterleakrepairpros.com
  Westminster, CO
  Site 09 of 50 — Leak Repair Network
============================================================

FOLDER STRUCTURE:
  images/
  ├── hero/
  │   ├── README.txt          ← Instructions for hero image
  │   └── hero-bg.jpg         ← 1 image  |  1200x600  |  UNIQUE to Westminster
  ├── local/
  │   ├── README.txt          ← Instructions for local/era images
  │   ├── era-pre1955.jpg     ← 1 image  |  800x500   |  UNIQUE to Westminster
  │   ├── era-1965-85.jpg     ← 1 image  |  800x500   |  UNIQUE to Westminster
  │   └── era-1990s-plus.jpg  ← 1 image  |  800x500   |  UNIQUE to Westminster
  └── services/
      ├── README.txt          ← Instructions for service images
      └── [54 images]         ← 800x500  |  SAME across all 50 sites

SUMMARY FOR THIS SITE:
  Unique images to create:   4  (1 hero + 3 local)
  Generic images to copy:   54  (service images — create once, copy here)
  Location page images:      0  (no images on location pages)
  Blog page images:          0  (blog reuses service images)
  ─────────────────────────────
  Total image files:        58

IMAGE SPECIFICATIONS:
  Format:      JPG or WebP (WebP preferred for smaller file size)
  Color space: RGB
  No text, watermarks, or logos in any image
  No stock photo watermarks — use licensed or original photography

WORKFLOW:
  Step 1 — Create the 4 unique Westminster images (hero + 3 local)
  Step 2 — Copy the 54 generic service images into images/services/
  Step 3 — Replace each .placeholder file with the actual image file
  Step 4 — Remove all .placeholder files before deployment

PLACEHOLDER FILES:
  Each folder contains .placeholder files marking where images go.
  Delete placeholders after placing the real image.
  The site will not display broken images — pages degrade gracefully
  until images are added.

─────────────────────────────────────────────────────────────────
  READ the README.txt in each folder before creating images.
─────────────────────────────────────────────────────────────────
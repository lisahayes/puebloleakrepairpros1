============================================================
  HERO IMAGE — highlandsranchleakrepairpros.com  |  Highlands Ranch, CO
============================================================

FOLDER:      images/hero/
DIMENSIONS:  1200 x 600 px
FILE SIZE:   Target under 200 KB  |  WebP preferred, JPG acceptable
FORMAT:      JPG or WebP  |  RGB color space  |  No transparency needed

IMPORTANT NOTES:
HERO IMAGE — UNIQUE PER SITE
This image appears behind the main headline on the homepage hero section.
A dark gradient overlay is applied in CSS (left side dark, right side slightly lighter).
The image must work with WHITE TEXT overlaid on the left portion.

SUBJECT: Highlands Ranch, CO — choose ONE of:
  • Highlands Ranch skyline or recognizable city view
  • Downtown Highlands Ranch main street or commercial district
  • Residential neighborhood street in Highlands Ranch
  • Well-known Highlands Ranch landmark or geographic feature

AVOID: Stock photos that look generic. Must feel like Highlands Ranch, CO specifically.
NO text, logos, or watermarks in the image.

────────────────────────────────────────────────────────────
  FILES TO CREATE (1 images)
────────────────────────────────────────────────────────────

  01. hero-bg.jpg
      Visual: Wide establishing shot of Highlands Ranch, CO. Works with white text overlay on left side. Dark gradient applied in CSS — image right side can be bright.

────────────────────────────────────────────────────────────
  STATUS TRACKING
────────────────────────────────────────────────────────────

  Mark each file DONE below as you complete it:

  [ ] hero-bg.jpg
